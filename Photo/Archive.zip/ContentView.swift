//
//  ContentView.swift
//  Photo
//
//  Created by Dano on 26.09.23.
//


// todo: ajouter fonction de scan de photo -> pdf

import SwiftUI

func saveImageToFile(image: NSImage) {
    
    guard let imageData = image.tiffRepresentation,
          let bitmapImageRep = NSBitmapImageRep(data: imageData) else {
        return
    }
    
    let properties: [NSBitmapImageRep.PropertyKey: Any] = [:]
    
    if let pngData = bitmapImageRep.representation(using: .png, properties: properties) {
        let savePanel = NSSavePanel()
        savePanel.allowedFileTypes = ["png"]
        savePanel.nameFieldStringValue = "SavedImage.png"
        
        if savePanel.runModal() == .OK,
           let saveURL = savePanel.url {
            do {
                try pngData.write(to: saveURL)
            } catch {
                print("Error saving image: \(error)")
            }
        }
    }
}

func resizeImage(image: NSImage?, width: CGFloat, height: CGFloat) -> NSImage? {
        guard let image = image else {
            return nil
        }

        let newSize = NSSize(width: width, height: height)
        let newImage = NSImage(size: newSize)

        newImage.lockFocus()
        defer {
            newImage.unlockFocus()
        }

        image.draw(in: NSRect(origin: .zero, size: newSize), from: NSRect(origin: .zero, size: image.size), operation: .sourceOver, fraction: 1.0)

        return newImage
    }

struct ContentView: View {
    @Binding var img: URL?
    @State var isGeometryPresented = false
    @State private var windowTitle = "Your Default Title"
    
    @State private var widthValue = "100"
    @State private var heightValue = "100"
    
    @Binding var resized_width: Int

    init(
        img: Binding<URL?> = .constant(URL(string: "file:///Users/dano/Pictures/lac et coucher de soleil.jpg")),
        resized_width: Binding<Int> = .constant(0))
    {
        _img = img
        _resized_width = resized_width
    }
    
    @State private var folderURL: URL?
    
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    var delegate = AppDelegate()
    
    @GestureState private var dragOffset = CGSize.zero
    @State var width = CGFloat(0)
    @State var height = CGFloat(0)
    @State private var scale: CGFloat = 1.0
    
    @State var presentAlert = false
    
    @State private var imagePosition = CGSize(width: -50, height: 0)
    @State var isEditMode = false
    
    @State var slidingValue = 0.0
    @State var PanelValue = EditPanelOption()
    
    
    
    var body: some View {
        HStack {

            let imagePath = img!.path
            
            let pth = String(imagePath).replacingOccurrences(of: "%20", with: "/ ")
            if let image = NSImage(contentsOfFile: pth) {
                Image(nsImage: image)
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(scale)
                    .offset((isEditMode) ? withAnimation(.easeInOut) { imagePosition} : CGSize(width: 50, height: 0))
                    .frame(width: (image.size.width<1000) ? image.size.width - width: 1000)
                    .scaleEffect((isEditMode) ? 0.8 : 1.0)
                    .onAppear {
                        widthValue = image.size.width.description
                        heightValue = image.size.height.description
                    }
                    .gesture(
                        
                        DragGesture()
                            .updating($dragOffset) { value, state, _ in
                                state = value.translation
                            }
                            .onChanged { value in
                                    
                                imagePosition = CGSize(width: value.translation.width, height: value.translation.height)
                            }

                    )
                    .onTapGesture {
                        NSApplication.shared.mainWindow?.setContentSize(NSSize(width: (image.size.width<1000) ? image.size.width + 200 : 1000, height: (image.size.width<1000) ? image.size.height : image.size.height/(image.size.width/1000)))
                    }
                    
            }
            else {
                Text(img!.absoluteString.dropFirst(7))
                Text("Image not found")
            }
            
            Spacer()
            
            if isEditMode {
                
                EditPanelView(sliderValue: $slidingValue, OptionValue: $PanelValue)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { // Change the delay time as needed
                                    updateWindowTitle()
            }
        }
        .toolbar {
            ToolbarItem (placement: .confirmationAction) {
                Button(action: {
                    isGeometryPresented = true
                }) {
                    Image(systemName: "viewfinder")
                }
                .sheet(isPresented: $isGeometryPresented, content: {
                    GeometrySheet(isGeometryPresented: $isGeometryPresented, Width: $widthValue, Height: $heightValue)
                })
            }
            
            ToolbarItem (placement: .confirmationAction) {
                Button(action: {
                    isEditMode.toggle()
                }, label: {Image(systemName: "slider.horizontal.3")})
                
            }
            
            // Image(nsImage: image).frame(width: widthValue, height: heightValue)
            
            
            ToolbarItem (placement: .confirmationAction) {
                Button("save") {
                    if let imagePath = img?.path {
                        let image = NSImage(contentsOfFile: imagePath)
                        let wdt = CGFloat(Double(widthValue)!)/2
                        let hgt = CGFloat(Double(heightValue)!)/2
                        let resizedImage = resizeImage(image: image, width: wdt, height: hgt)
                        saveImageToFile(image: resizedImage!)
                        print(widthValue)
                        exit(0)
                    }
                }
            }
        }
        
        
    }
    private func updateWindowTitle() {
            if let img = img {
                windowTitle = "\(img.lastPathComponent)"
            } else {
                windowTitle = "Photo"
            }
            NSApplication.shared.mainWindow?.title = windowTitle
        }
}


class AppDelegate: NSObject, NSApplicationDelegate {
    
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true
    }
    
    func applicationDidUpdate(_ notification: Notification) {
        
    }
    
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

// .sheet
